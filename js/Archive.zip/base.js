 $('.hm_slider').bxSlider({
	  pager: false,
	  controls: true,
	  auto: false,
	  infiniteLoop: true
  })	

$('.trending').bxSlider({
	slideWidth: 275,
	minSlides: 3,
    maxSlides: 4,
	slideMargin: 20,
	infiniteLoop: false,
	hideControlOnEnd: true,
	pager: false
});
  // Sales Items JS Ends here
  
  
$('.latest').bxSlider({
	slideWidth: 370,
	minSlides: 2,
    maxSlides: 3,
	slideMargin: 20,
	infiniteLoop: false,
	hideControlOnEnd: true,
	pager: false
});
  // Latest Movie JS Ends here
